import java.util.*;
class Main {
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        float r = obj.nextFloat();
        float area = (float)3.14*r*r;
        System.out.printf("%2f",area);
    }
}