import java.util.*;
class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        if(a%3 == 0) {
            System.out.print("Divisible by 3");
        }
        else {
            System.out.print("No Divisible by 3 & Remainder is" + a % 3);
        }
    }
}